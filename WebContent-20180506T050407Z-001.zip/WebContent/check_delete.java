import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class UserDataServlet
 */
@SuppressWarnings("serial")
public class add_details extends HttpServlet {

 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  // TODO Auto-generated method stub
  response.setContentType("text/html");
  PrintWriter out = response.getWriter();
  String name=request.getParameter("stu_name");
  String room=request.getParameter("room");

  // validate given input
  if (name.isEmpty()||room.isEmpty()||presence.isEmpty()) {
   RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
   out.println("<font color=red>Please fill all the fields</font>");
   rd.include(request, response);
  } else {
   try {
    Class.forName("com.mysql.jdbc.Driver");
    // loads mysql driver

    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hostel", "root", "");
    String query="delete from student where name=? and room=?";
PreparedStatement ps=con.prepareStatement(query);
                      ps.setString(1, name);
                      ps.setString(2, room);
                      ps.executeUpdate();
                 //ResultSet rs=ps.executeQuery();
                  HttpSession session=request.getSession(false);
	if(session!=null)
	{
		  /* checkname=rs.getString("name");
	     checkpass=rs.getString("password"); */
      
     //   RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
       // rd.forward(request, response);
      // response.sendRedirect("details.jsp");
       out.println("successfuly inserted man");
       System.out.println("successfuly inserted");
	}
	else
	{
		//RequestDispatcher rd = request.getRequestDispatcher("index.html");
    response.sendRedirect("index.html");
		out.println("<font color=red>you are already logged out</font>");
		//rd.include(request, response);
	}
    con.close();
   } catch (ClassNotFoundException | SQLException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
  
  }
 }
}
