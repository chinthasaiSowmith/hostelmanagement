import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class UserDataServlet
 */
@SuppressWarnings("serial")
public class check_status extends HttpServlet {

 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  // TODO Auto-generated method stub
  response.setContentType("text/html");
  PrintWriter out = response.getWriter();
  String name=request.getParameter("stu_name");
  String room=request.getParameter("room");

  // validate given input
  if (name.isEmpty()||room.isEmpty()) {
   RequestDispatcher rd = request.getRequestDispatcher("status.jsp");
   out.println("<font color=red>Please fill all the fields</font>");
   rd.include(request, response);
  } else {
   try {
    Class.forName("com.mysql.jdbc.Driver");
    // loads mysql driver

    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hostel", "root", "");
PreparedStatement ps=con.prepareStatement("select * from student where name=? and room=?");
                      ps.setString(1, name);
                      ps.setString(2,room);
                      ResultSet rs=ps.executeQuery();
                  HttpSession session=request.getSession(false);
                  if(rs.next())
  {
      /* checkname=rs.getString("name");
       checkpass=rs.getString("password"); */
      
          String checkname=rs.getString("name");
          String checkemail=rs.getString("email");
          String checkplace=rs.getString("place");
          String checkdate=rs.getString("date");
          int checkfees=rs.getInt("fees");
          String checkroom=rs.getString("room");
          String checkin=rs.getString("in");
          out.println("the name is"+checkname);
          out.println("the email is"+checkemail);
          out.println("the place is"+checkplace);
          out.println("the date of joining is"+checkdate);
          out.println("the fees paid is "+checkfees);
          out.println("the room no is"+checkroom);
          out.println("is he in room?"+checkin);
     //   RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
       // rd.forward(request, response);
       //response.sendRedirect("check_admin.html");
       System.out.println("successfuly came to check_status.java");
  }
  else
  {
    //RequestDispatcher rd = request.getRequestDispatcher("index.html");
    response.sendRedirect("status.jsp");
    out.println("<font color=red>Please enter valid values</font>");
    //rd.include(request, response);
  }
    con.close();
   } catch (ClassNotFoundException | SQLException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
  
  }
 }
}
