import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.mysql.jdbc.Statement;
/**
 * Servlet implementation class UserDataServlet
 */
public class all_students extends HttpServlet {

 /**
	 * 
	 */
	private static final long serialVersionUID = -7174889795588144783L;

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  // TODO Auto-generated method stub
  response.setContentType("text/html");
  PrintWriter out = response.getWriter();
  String room="laskj"; String name="sal;fkj";
  // validate given input
  if (name.isEmpty()||room.isEmpty()) {
   RequestDispatcher rd = request.getRequestDispatcher("status.jsp");
   out.println("<font color=red>Please fill all the fields</font>");
   rd.include(request, response);
  } else {
   try {
    Class.forName("com.mysql.jdbc.Driver");
    // loads mysql driver

    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hostel", "root", "");
PreparedStatement ps=con.prepareStatement("select * from student");
                      ResultSet rs=ps.executeQuery();
                      HttpSession session=request.getSession(false);
                   /*   if(session==null)
                      {
                    	 // response.sendRedirect("index.html");
                    	  
                    	//  RequestDispatcher rd = request.getRequestDispatcher("index.html");
                        //   rd.forward(request, response);
                        response.sendRedirect("index.html");
                           out.println("you are logged out");
                      } */
                  int l=0;
                  String output="<table border='2'>";
                  output=output+"<tr>";
                  output=output+"<td>NAME</td><td>EMAIL</td><td>PLACE</td><td>DATE</td><td>FEES</td><td>ROOM</td><td>IN</td></tr>";
                  while(rs.next())
  {
      /* checkname=rs.getString("name");
       checkpass=rs.getString("password"); */
          l=1;
          String checkname=rs.getString("name");
          String checkemail=rs.getString("email");
          String checkplace=rs.getString("place");
          String checkdate=rs.getString("date");
          int checkfees=rs.getInt("fees");
          String checkroom=rs.getString("room");
          String checkin=rs.getString("coming");
          output=output+"<tr>";
          output=output+"<td>"+checkname+"</td>";
          output=output+"<td>"+checkemail+"</td>";
          output=output+"<td>"+checkplace+"</td>";
          output=output+"<td>"+checkdate+"</td>";
          output=output+"<td>"+checkfees+"</td>";
          output=output+"<td>"+checkroom+"</td>";
          output=output+"<td>"+checkin+"</td>";
          output=output+"</tr>";
     //   RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
       // rd.forward(request, response);
       //response.sendRedirect("check_admin.html");
       System.out.println("successfuly came to check_status.java");
  } 
    output=output+"</table>";
    out.println(output);
    con.close();
   } catch (ClassNotFoundException | SQLException e) {
    // TODO Auto-generated catch block
    e.printStackTrace();
   }
  
  }
 }
}
